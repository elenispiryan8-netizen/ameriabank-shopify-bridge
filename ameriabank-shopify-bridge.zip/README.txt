
Ameriabank Shopify Bridge

1. Upload this project to Render or any Node hosting.
2. Set environment variables:
   SHOPIFY_STORE
   SHOPIFY_TOKEN
   AMERIA_CLIENT_ID
   AMERIA_USERNAME
   AMERIA_PASSWORD
   BASE_URL

3. Start server.
4. Open:
   /create-payment?order_id=SHOPIFY_ORDER_ID
